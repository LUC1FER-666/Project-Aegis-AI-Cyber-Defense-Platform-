"use client";

import { useEffect, useState, useCallback } from "react";
import {
  fetchStats, fetchAlerts, fetchIncidents, fetchTasks,
  approveTask, rejectTask,
  type DetectionStats, type Alert, type Incident, type AgentTask,
} from "@/lib/api";
import MetricCard from "@/components/MetricCard";
import SeverityBadge from "@/components/SeverityBadge";
import StatusBadge from "@/components/StatusBadge";
import { SkeletonMetric, SkeletonRow } from "@/components/LoadingSkeleton";
import { timeAgo } from "@/lib/api";

const SEV_COLORS: Record<string, string> = {
  critical: "#ff4444", high: "#ff8800", medium: "#f59e0b", low: "#00ff88",
};

function SeverityBar({ alerts }: { alerts: Alert[] }) {
  const counts = { critical: 0, high: 0, medium: 0, low: 0 };
  for (const a of alerts) {
    const k = a.severity?.toLowerCase() as keyof typeof counts;
    if (k in counts) counts[k]++;
  }
  const total = Object.values(counts).reduce((a, b) => a + b, 0) || 1;

  return (
    <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl p-5">
      <h3 className="text-xs text-[#64748b] uppercase tracking-widest mb-4">Alert Severity Breakdown</h3>
      <div className="space-y-3">
        {(["critical", "high", "medium", "low"] as const).map(sev => (
          <div key={sev} className="flex items-center gap-3">
            <span className="text-xs w-16 capitalize" style={{ color: SEV_COLORS[sev] }}>{sev}</span>
            <div className="flex-1 h-2 bg-[#1a2744] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${(counts[sev] / total) * 100}%`, background: SEV_COLORS[sev] }}
              />
            </div>
            <span className="text-xs text-[#64748b] w-6 text-right">{counts[sev]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [stats, setStats] = useState<DetectionStats | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [pendingTasks, setPendingTasks] = useState<AgentTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [approvalNotes, setApprovalNotes] = useState<Record<string, string>>({});

  const refresh = useCallback(async () => {
    const [s, a, i, t] = await Promise.all([
      fetchStats(),
      fetchAlerts({ limit: 10 }),
      fetchIncidents({ limit: 5 }),
      fetchTasks({ status: "pending_approval", page_size: 10 }),
    ]);
    if (s) setStats(s);
    setAlerts(a);
    setIncidents(i);
    setPendingTasks(t.tasks);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 10_000);
    return () => clearInterval(t);
  }, [refresh]);

  const handleApprove = async (taskId: string) => {
    await approveTask(taskId, approvalNotes[taskId] ?? "", "soc-analyst");
    refresh();
  };
  const handleReject = async (taskId: string) => {
    await rejectTask(taskId, approvalNotes[taskId] ?? "");
    refresh();
  };

  return (
    <div className="p-6 space-y-6 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-[#e2e8f0]">SOC Dashboard</h1>
          <p className="text-xs text-[#64748b] mt-0.5">Live threat overview · updates every 10s</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] animate-pulse" />
          <span className="text-xs text-[#64748b]">Live</span>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-4 gap-4">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => <SkeletonMetric key={i} />)
        ) : (
          <>
            <MetricCard label="Total Alerts" value={stats?.total_alerts ?? 0} color="#ff4444" sub={`${stats?.alerts_last_hour ?? 0} in last hour`} />
            <MetricCard label="Open Incidents" value={stats?.open_incidents ?? 0} color="#ff8800" sub={`${stats?.total_incidents ?? 0} total`} />
            <MetricCard label="Pending Approvals" value={pendingTasks.length} color="#f59e0b" sub="agent tasks awaiting review" />
            <MetricCard label="Rules Loaded" value={stats?.rules_loaded ?? 0} color="#00d4ff" sub={stats?.ml_model_trained ? "ML model trained" : "ML not trained"} />
          </>
        )}
      </div>

      {/* Severity bar + pending tasks */}
      <div className="grid grid-cols-2 gap-4">
        <SeverityBar alerts={alerts} />

        {/* Pending Approvals */}
        <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl p-5">
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest mb-4">Pending Approvals</h3>
          {pendingTasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-24 text-[#64748b] text-sm">
              <span className="text-2xl mb-1">✓</span>No tasks awaiting approval
            </div>
          ) : (
            <div className="space-y-3 max-h-48 overflow-y-auto">
              {pendingTasks.map(task => (
                <div key={task.id} className="bg-[#060d1f] rounded-lg p-3 border border-[#1a2744]">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <p className="text-sm text-[#e2e8f0] font-medium leading-tight">{task.incident_title}</p>
                      <p className="text-xs text-[#64748b] mt-0.5">{task.selected_playbook?.replace(/_/g, " ")}</p>
                    </div>
                    <SeverityBadge severity={task.severity} />
                  </div>
                  <input
                    type="text"
                    placeholder="Notes (optional)"
                    value={approvalNotes[task.id] ?? ""}
                    onChange={e => setApprovalNotes(prev => ({ ...prev, [task.id]: e.target.value }))}
                    className="w-full text-xs bg-[#1a2744] border border-[#1a2744] rounded px-2 py-1 text-[#e2e8f0] placeholder-[#64748b] mb-2 outline-none focus:border-[#00d4ff]/40"
                  />
                  <div className="flex gap-2">
                    <button onClick={() => handleApprove(task.id)}
                      className="flex-1 text-xs py-1 rounded bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/30 hover:bg-[#00ff88]/20 transition-colors">
                      Approve
                    </button>
                    <button onClick={() => handleReject(task.id)}
                      className="flex-1 text-xs py-1 rounded bg-[#ff4444]/10 text-[#ff4444] border border-[#ff4444]/30 hover:bg-[#ff4444]/20 transition-colors">
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Alerts */}
      <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-[#1a2744]">
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest">Recent Alerts</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1a2744]">
                {["Severity", "Rule", "Asset", "Technique", "Confidence", "Time"].map(h => (
                  <th key={h} className="px-4 py-2.5 text-left text-[10px] text-[#64748b] uppercase tracking-widest font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading
                ? Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} cols={6} />)
                : alerts.length === 0
                ? (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-[#64748b] text-sm">No alerts yet — submit events from the simulator</td></tr>
                )
                : alerts.map(a => (
                  <tr key={a.alert_id} className="border-b border-[#1a2744]/50 hover:bg-[#1a2744]/20 transition-colors">
                    <td className="px-4 py-3"><SeverityBadge severity={a.severity} /></td>
                    <td className="px-4 py-3 font-mono text-xs text-[#00d4ff]">{a.rule_id}</td>
                    <td className="px-4 py-3 text-xs text-[#e2e8f0]">{a.asset_id || "—"}</td>
                    <td className="px-4 py-3 text-xs text-[#64748b] font-mono">{a.mitre_technique}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-[#1a2744] rounded-full overflow-hidden">
                          <div className="h-full bg-[#00d4ff] rounded-full" style={{ width: `${(a.confidence_score ?? 0) * 100}%` }} />
                        </div>
                        <span className="text-xs text-[#64748b]">{Math.round((a.confidence_score ?? 0) * 100)}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-[#64748b]">{timeAgo(a.created_at)}</td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Incidents */}
      <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-[#1a2744]">
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest">Recent Incidents</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1a2744]">
                {["Severity", "Title", "Alerts", "Assets", "Status", "Time"].map(h => (
                  <th key={h} className="px-4 py-2.5 text-left text-[10px] text-[#64748b] uppercase tracking-widest font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading
                ? Array.from({ length: 3 }).map((_, i) => <SkeletonRow key={i} cols={6} />)
                : incidents.length === 0
                ? <tr><td colSpan={6} className="px-4 py-8 text-center text-[#64748b] text-sm">No incidents correlated yet</td></tr>
                : incidents.map(inc => (
                  <tr key={inc.incident_id} className="border-b border-[#1a2744]/50 hover:bg-[#1a2744]/20 transition-colors">
                    <td className="px-4 py-3"><SeverityBadge severity={inc.severity} /></td>
                    <td className="px-4 py-3 text-xs text-[#e2e8f0] max-w-xs truncate">{inc.title}</td>
                    <td className="px-4 py-3">
                      <span className="text-xs bg-[#1a2744] text-[#00d4ff] px-2 py-0.5 rounded-full">{inc.alert_count}</span>
                    </td>
                    <td className="px-4 py-3 text-xs text-[#64748b]">{inc.affected_assets?.length ?? 0} assets</td>
                    <td className="px-4 py-3"><StatusBadge status={inc.status} /></td>
                    <td className="px-4 py-3 text-xs text-[#64748b]">{timeAgo(inc.created_at)}</td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
