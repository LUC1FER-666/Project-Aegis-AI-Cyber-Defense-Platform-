"use client";

import { useEffect, useState, useCallback } from "react";
import { fetchRules, type Rule } from "@/lib/api";
import SeverityBadge from "@/components/SeverityBadge";
import { SkeletonRow } from "@/components/LoadingSkeleton";

const DE = process.env.NEXT_PUBLIC_DETECTION_ENGINE_URL ?? "http://localhost:8004";

async function patchRule(ruleId: string, enabled: boolean) {
  try {
    await fetch(`${DE}/api/v1/rules/${ruleId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled }),
    });
  } catch {}
}

export default function RulesPage() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Rule | null>(null);
  const [localEnabled, setLocalEnabled] = useState<Record<string, boolean>>({});

  const refresh = useCallback(async () => {
    setLoading(true);
    const data = await fetchRules();
    setRules(data);
    const init: Record<string, boolean> = {};
    for (const r of data) init[r.rule_id] = r.enabled ?? true;
    setLocalEnabled(init);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const toggle = async (ruleId: string) => {
    const newVal = !localEnabled[ruleId];
    setLocalEnabled(prev => ({ ...prev, [ruleId]: newVal }));
    await patchRule(ruleId, newVal);
  };

  const sigmaCount = rules.filter(r => r.type === "sigma").length;
  const mlCount = rules.filter(r => r.type === "ml").length;
  const enabledCount = Object.values(localEnabled).filter(Boolean).length;

  return (
    <div className="p-6 space-y-5 min-h-full">
      <div>
        <h1 className="text-xl font-bold text-[#e2e8f0]">Detection Rules</h1>
        <p className="text-xs text-[#64748b] mt-0.5">Sigma rules and ML models loaded in the detection engine</p>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Total Rules", value: rules.length, color: "#00d4ff" },
          { label: "Enabled", value: enabledCount, color: "#00ff88" },
          { label: "Sigma", value: sigmaCount, color: "#f59e0b" },
          { label: "ML Models", value: mlCount, color: "#ff8800" },
        ].map(m => (
          <div key={m.label} className="bg-[#0d1528] border border-[#1a2744] rounded-xl px-4 py-3">
            <div className="text-[10px] text-[#64748b] uppercase tracking-widest">{m.label}</div>
            <div className="text-2xl font-bold mt-0.5" style={{ color: m.color }}>{m.value}</div>
          </div>
        ))}
      </div>

      {/* Table + detail */}
      <div className="flex gap-4">
        <div className="flex-1 bg-[#0d1528] border border-[#1a2744] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1a2744]">
                  {["Rule ID", "Title", "Severity", "MITRE", "Type", "Hits", "Enabled"].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[10px] text-[#64748b] uppercase tracking-widest font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading
                  ? Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} cols={7} />)
                  : rules.length === 0
                  ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-16 text-center">
                        <div className="text-[#64748b] space-y-2">
                          <div className="text-3xl">◉</div>
                          <div className="text-sm">No rules loaded</div>
                          <div className="text-xs">Start the detection engine to load rules</div>
                        </div>
                      </td>
                    </tr>
                  )
                  : rules.map(r => (
                    <tr
                      key={r.rule_id}
                      onClick={() => setSelected(selected?.rule_id === r.rule_id ? null : r)}
                      className={`border-b border-[#1a2744]/50 cursor-pointer transition-colors ${selected?.rule_id === r.rule_id ? "bg-[#00d4ff]/5" : "hover:bg-[#1a2744]/20"}`}
                    >
                      <td className="px-4 py-3 font-mono text-xs text-[#00d4ff]">{r.rule_id}</td>
                      <td className="px-4 py-3 text-xs text-[#e2e8f0] max-w-[200px] truncate">{r.title}</td>
                      <td className="px-4 py-3"><SeverityBadge severity={r.severity} /></td>
                      <td className="px-4 py-3 text-xs font-mono text-[#64748b]">{r.mitre_technique}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium
                          ${r.type === "sigma" ? "bg-[#f59e0b]/10 text-[#f59e0b] border-[#f59e0b]/30" : "bg-[#ff8800]/10 text-[#ff8800] border-[#ff8800]/30"}`}>
                          {r.type}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-[#64748b]">{r.hit_count ?? 0}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={e => { e.stopPropagation(); toggle(r.rule_id); }}
                          className={`relative w-10 h-5 rounded-full transition-colors duration-200 ${localEnabled[r.rule_id] ? "bg-[#00ff88]/30" : "bg-[#1a2744]"}`}
                        >
                          <span className={`absolute top-0.5 w-4 h-4 rounded-full transition-transform duration-200 ${localEnabled[r.rule_id] ? "translate-x-5 bg-[#00ff88]" : "translate-x-0.5 bg-[#64748b]"}`} />
                        </button>
                      </td>
                    </tr>
                  ))
                }
              </tbody>
            </table>
          </div>
        </div>

        {/* Detail panel */}
        {selected && (
          <div className="w-72 bg-[#0d1528] border border-[#1a2744] rounded-xl p-5 space-y-4 flex-shrink-0">
            <div className="flex items-start justify-between">
              <h3 className="text-sm font-semibold text-[#e2e8f0] leading-tight">{selected.title}</h3>
              <button onClick={() => setSelected(null)} className="text-[#64748b] hover:text-[#e2e8f0] text-sm">✕</button>
            </div>

            <div className="space-y-2">
              {[
                ["Rule ID", selected.rule_id, "font-mono text-[#00d4ff]"],
                ["Type", selected.type, "capitalize"],
                ["MITRE", selected.mitre_technique, "font-mono"],
                ["Hits", String(selected.hit_count ?? 0), ""],
              ].map(([k, v, cls]) => (
                <div key={k} className="bg-[#060d1f] rounded-lg px-3 py-2 border border-[#1a2744]">
                  <div className="text-[10px] text-[#64748b] uppercase tracking-widest mb-0.5">{k}</div>
                  <div className={`text-xs text-[#e2e8f0] ${cls}`}>{v}</div>
                </div>
              ))}
            </div>

            <div>
              <SeverityBadge severity={selected.severity} />
            </div>

            {selected.description && (
              <div>
                <div className="text-[10px] text-[#64748b] uppercase tracking-widest mb-1">Description</div>
                <p className="text-xs text-[#64748b] leading-relaxed">{selected.description}</p>
              </div>
            )}

            {selected.tags && selected.tags.length > 0 && (
              <div>
                <div className="text-[10px] text-[#64748b] uppercase tracking-widest mb-2">Tags</div>
                <div className="flex flex-wrap gap-1">
                  {selected.tags.map(tag => (
                    <span key={tag} className="text-[10px] bg-[#1a2744] text-[#64748b] px-2 py-0.5 rounded">{tag}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
