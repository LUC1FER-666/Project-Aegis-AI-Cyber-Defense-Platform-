"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { fetchStats, fetchAgentStats } from "@/lib/api";
import "./globals.css";

function NavItem({
  href, label, icon, badge,
}: {
  href: string; label: string; icon: string; badge?: number;
}) {
  const path = usePathname();
  const active = path === href || (href !== "/" && path.startsWith(href));
  return (
    <Link
      href={href}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-150 group
        ${active
          ? "bg-[#00d4ff]/10 text-[#00d4ff] border border-[#00d4ff]/20"
          : "text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a2744]/60 border border-transparent"
        }`}
    >
      <span className="text-base w-5 text-center">{icon}</span>
      <span className="flex-1">{label}</span>
      {badge !== undefined && badge > 0 && (
        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#ff4444] text-white min-w-[18px] text-center">
          {badge > 99 ? "99+" : badge}
        </span>
      )}
    </Link>
  );
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const [openAlerts, setOpenAlerts] = useState(0);
  const [pendingTasks, setPendingTasks] = useState(0);

  const refreshCounts = useCallback(async () => {
    const [stats, agentStats] = await Promise.all([fetchStats(), fetchAgentStats()]);
    if (stats) setOpenAlerts(stats.open_alerts ?? 0);
    if (agentStats) setPendingTasks(agentStats.pending_approval_count ?? 0);
  }, []);

  useEffect(() => {
    refreshCounts();
    const t = setInterval(refreshCounts, 10_000);
    return () => clearInterval(t);
  }, [refreshCounts]);

  return (
    <html lang="en">
      <head>
        <title>Aegis AI — Cyber Defense</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body style={{ background: "#0a0f1e", color: "#e2e8f0", fontFamily: "system-ui, sans-serif", margin: 0 }}>
        <div className="flex h-screen overflow-hidden">
          {/* Sidebar */}
          <aside className="w-56 flex-shrink-0 flex flex-col border-r border-[#1a2744] bg-[#0a0f1e]">
            {/* Logo */}
            <div className="px-4 py-5 border-b border-[#1a2744]">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold"
                  style={{ background: "linear-gradient(135deg, #00d4ff22, #00d4ff44)", border: "1px solid #00d4ff44", color: "#00d4ff" }}>
                  ⬡
                </div>
                <div>
                  <div className="text-sm font-bold text-[#e2e8f0]">Aegis AI</div>
                  <div className="text-[10px] text-[#64748b] uppercase tracking-widest">SOC Platform</div>
                </div>
              </div>
            </div>

            {/* Nav */}
            <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
              <NavItem href="/" label="Dashboard" icon="◈" />
              <NavItem href="/alerts" label="Alerts" icon="⚡" badge={openAlerts} />
              <NavItem href="/incidents" label="Incidents" icon="🔴" />
              <NavItem href="/tasks" label="Agent Tasks" icon="⚙" badge={pendingTasks} />
              <NavItem href="/rules" label="Detection Rules" icon="◉" />
              <div className="pt-3 pb-1">
                <div className="px-3 text-[10px] text-[#64748b] uppercase tracking-widest">Tools</div>
              </div>
              <NavItem href="/simulator" label="Event Simulator" icon="▶" />
            </nav>

            {/* Status indicator */}
            <div className="px-4 py-3 border-t border-[#1a2744]">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] animate-pulse" />
                <span className="text-[10px] text-[#64748b]">Systems operational</span>
              </div>
            </div>
          </aside>

          {/* Main content */}
          <main className="flex-1 overflow-y-auto">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
