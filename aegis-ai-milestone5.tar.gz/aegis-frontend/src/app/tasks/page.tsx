"use client";

import { useEffect, useState, useCallback } from "react";
import {
  fetchTasks, fetchTask, fetchTaskActions,
  approveTask, rejectTask,
  type AgentTask, type ActionLog, timeAgo,
} from "@/lib/api";
import SeverityBadge from "@/components/SeverityBadge";
import StatusBadge from "@/components/StatusBadge";
import JsonViewer from "@/components/JsonViewer";
import { SkeletonCard } from "@/components/LoadingSkeleton";

const TABS = ["all", "pending_approval", "executing", "completed", "failed"] as const;
type Tab = typeof TABS[number];

const URGENCY_COLOR = (s: number) =>
  s >= 0.8 ? "#ff4444" : s >= 0.6 ? "#ff8800" : s >= 0.4 ? "#f59e0b" : "#00ff88";

function UrgencyGauge({ score }: { score: number }) {
  const color = URGENCY_COLOR(score);
  const deg = score * 180;
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-24 h-12 overflow-hidden">
        <div className="absolute inset-0 rounded-t-full border-4 border-[#1a2744]" style={{ borderBottom: "none" }} />
        <div
          className="absolute bottom-0 left-1/2 w-0.5 h-10 origin-bottom transition-transform duration-700"
          style={{ background: color, transform: `translateX(-50%) rotate(${deg - 90}deg)` }}
        />
        <div className="absolute bottom-0 left-1/2 w-2 h-2 rounded-full -translate-x-1/2 translate-y-1/2" style={{ background: color }} />
      </div>
      <span className="text-lg font-bold" style={{ color }}>{Math.round(score * 100)}%</span>
      <span className="text-[10px] text-[#64748b]">Urgency</span>
    </div>
  );
}

function ActionCard({ action, log }: { action?: AgentTask["actions_results"] extends Array<infer T> ? T : never; log?: ActionLog }) {
  const [open, setOpen] = useState(false);
  const data = action ?? log;
  if (!data) return null;
  const statusColor = data.status === "success" ? "#00ff88" : data.status === "failed" ? "#ff4444" : "#64748b";

  return (
    <div className="border border-[#1a2744] rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 py-2.5 bg-[#060d1f] hover:bg-[#1a2744]/30 transition-colors text-left"
      >
        <div className="flex items-center gap-3">
          <span className="text-sm" style={{ color: statusColor }}>
            {data.status === "success" ? "✓" : data.status === "failed" ? "✗" : "○"}
          </span>
          <span className="text-xs font-mono text-[#e2e8f0]">{data.action_type}</span>
          <span className="text-[10px] text-[#64748b]">{data.target}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[10px] text-[#64748b]">{data.duration_ms}ms</span>
          <span className="text-[10px] text-[#64748b]">{open ? "▲" : "▼"}</span>
        </div>
      </button>
      {open && (
        <div className="px-4 py-3 border-t border-[#1a2744]">
          <JsonViewer data={data.result_data} maxHeight="180px" />
        </div>
      )}
    </div>
  );
}

function TaskDetail({ taskId, onRefresh }: { taskId: string; onRefresh: () => void }) {
  const [task, setTask] = useState<AgentTask | null>(null);
  const [logs, setLogs] = useState<ActionLog[]>([]);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [t, l] = await Promise.all([fetchTask(taskId), fetchTaskActions(taskId)]);
    setTask(t);
    setLogs(l);
    setLoading(false);
  }, [taskId]);

  useEffect(() => { load(); }, [load]);

  const handleApprove = async () => {
    await approveTask(taskId, notes, "soc-analyst");
    onRefresh(); load();
  };
  const handleReject = async () => {
    await rejectTask(taskId, notes);
    onRefresh(); load();
  };

  if (loading || !task) {
    return (
      <div className="flex-1 flex items-center justify-center text-[#64748b] text-sm">
        {loading ? "Loading..." : "Select a task"}
      </div>
    );
  }

  const t = task.triage;
  const actions = task.actions_results ?? [];

  return (
    <div className="flex-1 overflow-y-auto p-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-[#e2e8f0] leading-tight">{task.incident_title}</h2>
          <p className="text-xs text-[#64748b] mt-0.5 font-mono">{task.id}</p>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <SeverityBadge severity={task.severity} />
          <StatusBadge status={task.status} />
        </div>
      </div>

      {/* Triage */}
      {t && (
        <div className="bg-[#060d1f] border border-[#1a2744] rounded-xl p-5">
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest mb-4">Triage Analysis</h3>
          <div className="flex items-start gap-6">
            <UrgencyGauge score={t.urgency_score} />
            <div className="flex-1 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#1a2744]/40 rounded-lg p-2">
                  <div className="text-[10px] text-[#64748b] mb-0.5">Attack Stage</div>
                  <div className="text-xs text-[#ff8800] font-medium">{t.attack_stage?.replace(/_/g, " ")}</div>
                </div>
                <div className="bg-[#1a2744]/40 rounded-lg p-2">
                  <div className="text-[10px] text-[#64748b] mb-0.5">Response Tier</div>
                  <div className="text-xs text-[#00d4ff] font-medium capitalize">{t.recommended_response_tier}</div>
                </div>
              </div>
              <p className="text-xs text-[#64748b] leading-relaxed">{t.summary}</p>
              <div className="flex flex-wrap gap-1">
                {t.key_indicators.map((k, i) => (
                  <span key={i} className="text-[10px] bg-[#1a2744] text-[#e2e8f0] px-2 py-0.5 rounded">{k}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Playbook */}
      {task.selected_playbook && (
        <div className="bg-[#060d1f] border border-[#1a2744] rounded-xl p-5">
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest mb-3">
            Playbook: <span className="text-[#00d4ff]">{task.selected_playbook.replace(/_/g, " ")}</span>
          </h3>
          <div className="space-y-1.5">
            {(task.playbook_steps ?? []).map((step, i) => {
              const result = actions[i];
              const icon = !result ? "○" : result.status === "success" ? "✓" : result.status === "failed" ? "✗" : "◌";
              const color = !result ? "#64748b" : result.status === "success" ? "#00ff88" : result.status === "failed" ? "#ff4444" : "#f59e0b";
              return (
                <div key={i} className="flex items-center gap-3 px-3 py-2 bg-[#1a2744]/20 rounded-lg">
                  <span className="w-5 text-center text-sm font-bold" style={{ color }}>{icon}</span>
                  <span className="text-xs font-mono text-[#e2e8f0]">{step.action_type}</span>
                  {step.target && <span className="text-[10px] text-[#64748b]">→ {step.target}</span>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Action Results */}
      {(actions.length > 0 || logs.length > 0) && (
        <div>
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest mb-3">Action Results</h3>
          <div className="space-y-2">
            {actions.length > 0
              ? actions.map((a, i) => <ActionCard key={i} action={a} />)
              : logs.map(l => <ActionCard key={l.id} log={l} />)
            }
          </div>
        </div>
      )}

      {/* Approval */}
      {task.status === "pending_approval" && (
        <div className="bg-[#060d1f] border border-[#ff8800]/30 rounded-xl p-5">
          <h3 className="text-xs text-[#ff8800] uppercase tracking-widest mb-3">⚠ Awaiting Approval</h3>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Approval notes (optional)..."
            rows={2}
            className="w-full bg-[#1a2744] border border-[#1a2744] rounded-lg px-3 py-2 text-sm text-[#e2e8f0] placeholder-[#64748b] outline-none focus:border-[#00d4ff]/40 resize-none mb-3"
          />
          <div className="flex gap-3">
            <button onClick={handleApprove}
              className="flex-1 py-2.5 rounded-lg bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/30 text-sm font-medium hover:bg-[#00ff88]/20 transition-colors">
              ✓ Approve & Execute
            </button>
            <button onClick={handleReject}
              className="flex-1 py-2.5 rounded-lg bg-[#ff4444]/10 text-[#ff4444] border border-[#ff4444]/30 text-sm font-medium hover:bg-[#ff4444]/20 transition-colors">
              ✗ Reject
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function TasksPage() {
  const [tasks, setTasks] = useState<AgentTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("all");
  const [refreshKey, setRefreshKey] = useState(0);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { tasks: data } = await fetchTasks({
      status: tab === "all" ? undefined : tab,
      page_size: 50,
    });
    setTasks(data);
    setLoading(false);
  }, [tab]);

  useEffect(() => { refresh(); }, [refresh, refreshKey]);
  useEffect(() => {
    const t = setInterval(refresh, 10_000);
    return () => clearInterval(t);
  }, [refresh]);

  return (
    <div className="flex h-full">
      {/* Left panel */}
      <div className="w-80 flex-shrink-0 flex flex-col border-r border-[#1a2744] overflow-hidden">
        {/* Tabs */}
        <div className="flex overflow-x-auto border-b border-[#1a2744]">
          {TABS.map(t => (
            <button
              key={t}
              onClick={() => { setTab(t); setSelectedId(null); }}
              className={`px-3 py-2.5 text-[10px] uppercase tracking-widest whitespace-nowrap flex-shrink-0 transition-colors border-b-2 ${
                tab === t ? "text-[#00d4ff] border-[#00d4ff]" : "text-[#64748b] border-transparent hover:text-[#e2e8f0]"
              }`}
            >
              {t.replace(/_/g, " ")}
            </button>
          ))}
        </div>

        {/* Task list */}
        <div className="flex-1 overflow-y-auto">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="p-3 border-b border-[#1a2744]"><SkeletonCard /></div>
            ))
            : tasks.length === 0
            ? (
              <div className="flex flex-col items-center justify-center h-48 text-[#64748b] text-sm">
                <span className="text-2xl mb-2">⚙</span>
                <span>No tasks</span>
              </div>
            )
            : tasks.map(task => (
              <button
                key={task.id}
                onClick={() => setSelectedId(task.id)}
                className={`w-full text-left p-4 border-b border-[#1a2744] hover:bg-[#1a2744]/30 transition-colors ${selectedId === task.id ? "bg-[#00d4ff]/5 border-l-2 border-l-[#00d4ff]" : ""}`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <p className="text-xs font-medium text-[#e2e8f0] leading-tight line-clamp-2">{task.incident_title}</p>
                  <SeverityBadge severity={task.severity} />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <StatusBadge status={task.status} />
                  <span className="text-[10px] text-[#64748b]">{timeAgo(task.created_at)}</span>
                </div>
                {task.triage?.urgency_score !== undefined && (
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1 bg-[#1a2744] rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${task.triage.urgency_score * 100}%`, background: URGENCY_COLOR(task.triage.urgency_score) }} />
                    </div>
                    <span className="text-[10px] text-[#64748b]">{Math.round(task.triage.urgency_score * 100)}%</span>
                  </div>
                )}
                {task.selected_playbook && (
                  <p className="text-[10px] text-[#64748b] mt-1 font-mono truncate">{task.selected_playbook}</p>
                )}
              </button>
            ))
          }
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex flex-col overflow-hidden bg-[#0a0f1e]">
        {selectedId
          ? <TaskDetail taskId={selectedId} onRefresh={() => setRefreshKey(k => k + 1)} />
          : (
            <div className="flex-1 flex flex-col items-center justify-center text-[#64748b] space-y-2">
              <span className="text-4xl">⚙</span>
              <span className="text-sm">Select a task to view details</span>
            </div>
          )
        }
      </div>
    </div>
  );
}
