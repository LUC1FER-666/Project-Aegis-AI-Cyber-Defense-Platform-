"use client";

import { useEffect, useState, useCallback } from "react";
import { fetchIncidents, type Incident, timeAgo } from "@/lib/api";
import SeverityBadge from "@/components/SeverityBadge";
import StatusBadge from "@/components/StatusBadge";
import { SkeletonCard } from "@/components/LoadingSkeleton";

const MITRE_DESC: Record<string, string> = {
  T1059: "Command & Scripting Interpreter",
  "T1059.001": "PowerShell execution",
  T1053: "Scheduled Task/Job",
  "T1053.005": "Scheduled Task",
  T1110: "Brute Force",
  T1071: "Application Layer Protocol",
  "T1071.004": "DNS C2 tunneling",
  T1571: "Non-Standard Port",
  T1021: "Remote Services",
  T1076: "Remote Desktop Protocol",
  T1041: "Exfiltration Over C2",
};

function IncidentCard({ inc, onSelect }: { inc: Incident; onSelect: () => void }) {
  const duration = inc.first_seen && inc.last_seen
    ? Math.max(0, new Date(inc.last_seen).getTime() - new Date(inc.first_seen).getTime())
    : 0;
  const durationMin = Math.floor(duration / 60000);

  return (
    <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl p-5 hover:border-[#00d4ff]/30 transition-all duration-200 group">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <SeverityBadge severity={inc.severity} />
            <span className="text-xs bg-[#00d4ff]/10 text-[#00d4ff] border border-[#00d4ff]/20 px-2 py-0.5 rounded-full">
              {inc.alert_count} alert{inc.alert_count !== 1 ? "s" : ""}
            </span>
          </div>
          <h3 className="text-sm font-semibold text-[#e2e8f0] leading-tight">{inc.title}</h3>
        </div>
        <StatusBadge status={inc.status} />
      </div>

      {/* Assets */}
      {inc.affected_assets?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {inc.affected_assets.slice(0, 3).map(asset => (
            <span key={asset} className="text-[10px] bg-[#1a2744] text-[#64748b] px-2 py-0.5 rounded font-mono">{asset}</span>
          ))}
          {inc.affected_assets.length > 3 && (
            <span className="text-[10px] text-[#64748b]">+{inc.affected_assets.length - 3} more</span>
          )}
        </div>
      )}

      {/* MITRE techniques */}
      {inc.mitre_techniques?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {inc.mitre_techniques.map(t => (
            <span key={t} className="text-[10px] bg-[#ff8800]/10 text-[#ff8800] border border-[#ff8800]/20 px-2 py-0.5 rounded font-mono">{t}</span>
          ))}
        </div>
      )}

      {/* Timeline bar */}
      <div className="mb-3">
        <div className="flex justify-between text-[10px] text-[#64748b] mb-1">
          <span>{timeAgo(inc.first_seen)}</span>
          <span>{durationMin > 0 ? `${durationMin}m duration` : "ongoing"}</span>
          <span>{timeAgo(inc.last_seen)}</span>
        </div>
        <div className="h-1 bg-[#1a2744] rounded-full overflow-hidden">
          <div className="h-full rounded-full bg-gradient-to-r from-[#ff8800] to-[#ff4444]" style={{ width: "100%" }} />
        </div>
      </div>

      <button
        onClick={onSelect}
        className="w-full text-xs py-2 rounded-lg bg-[#00d4ff]/10 text-[#00d4ff] border border-[#00d4ff]/20 hover:bg-[#00d4ff]/20 transition-colors"
      >
        View Details →
      </button>
    </div>
  );
}

function DetailPanel({ inc, onClose }: { inc: Incident; onClose: () => void }) {
  return (
    <div className="fixed inset-y-0 right-0 w-[480px] bg-[#0d1528] border-l border-[#1a2744] shadow-2xl z-50 flex flex-col overflow-hidden"
      style={{ boxShadow: "-20px 0 60px #00000080" }}>
      {/* Header */}
      <div className="px-6 py-4 border-b border-[#1a2744] flex items-start justify-between gap-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <SeverityBadge severity={inc.severity} />
            <StatusBadge status={inc.status} />
          </div>
          <h2 className="text-sm font-semibold text-[#e2e8f0] leading-tight">{inc.title}</h2>
        </div>
        <button onClick={onClose} className="text-[#64748b] hover:text-[#e2e8f0] transition-colors text-lg">✕</button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
        {/* Overview */}
        <div className="grid grid-cols-2 gap-3">
          {[
            ["Alert Count", inc.alert_count],
            ["Affected Assets", inc.affected_assets?.length ?? 0],
            ["First Seen", timeAgo(inc.first_seen)],
            ["Last Seen", timeAgo(inc.last_seen)],
          ].map(([k, v]) => (
            <div key={String(k)} className="bg-[#060d1f] rounded-lg p-3 border border-[#1a2744]">
              <div className="text-[10px] text-[#64748b] uppercase tracking-widest mb-1">{k}</div>
              <div className="text-sm font-semibold text-[#e2e8f0]">{String(v)}</div>
            </div>
          ))}
        </div>

        {/* MITRE Techniques */}
        <div>
          <h4 className="text-xs text-[#64748b] uppercase tracking-widest mb-3">MITRE ATT&CK Techniques</h4>
          <div className="space-y-2">
            {inc.mitre_techniques?.map(t => (
              <div key={t} className="flex items-center gap-3 bg-[#060d1f] rounded-lg p-3 border border-[#1a2744]">
                <span className="text-xs font-mono text-[#ff8800] font-bold">{t}</span>
                <span className="text-xs text-[#64748b]">{MITRE_DESC[t] ?? "Unknown technique"}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Affected Assets */}
        {inc.affected_assets?.length > 0 && (
          <div>
            <h4 className="text-xs text-[#64748b] uppercase tracking-widest mb-3">Affected Assets</h4>
            <div className="space-y-1.5">
              {inc.affected_assets.map(asset => (
                <div key={asset} className="flex items-center gap-2 bg-[#060d1f] rounded-lg px-3 py-2 border border-[#1a2744]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#ff4444]" />
                  <span className="text-xs font-mono text-[#e2e8f0]">{asset}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Correlation key */}
        <div>
          <h4 className="text-xs text-[#64748b] uppercase tracking-widest mb-2">Correlation Key</h4>
          <div className="bg-[#060d1f] rounded-lg px-3 py-2 border border-[#1a2744]">
            <span className="text-xs font-mono text-[#00d4ff]">{inc.correlation_key}</span>
          </div>
        </div>

        {/* Incident ID */}
        <div>
          <h4 className="text-xs text-[#64748b] uppercase tracking-widest mb-2">Incident ID</h4>
          <div className="bg-[#060d1f] rounded-lg px-3 py-2 border border-[#1a2744]">
            <span className="text-xs font-mono text-[#64748b]">{inc.incident_id}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function IncidentsPage() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Incident | null>(null);
  const [statusFilter, setStatusFilter] = useState("");
  const [severityFilter, setSeverityFilter] = useState("");
  const [search, setSearch] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true);
    const data = await fetchIncidents({ status: statusFilter || undefined, severity: severityFilter || undefined });
    const filtered = search
      ? data.filter(i => i.title.toLowerCase().includes(search.toLowerCase()))
      : data;
    setIncidents(filtered);
    setLoading(false);
  }, [statusFilter, severityFilter, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    const t = setInterval(refresh, 10_000);
    return () => clearInterval(t);
  }, [refresh]);

  return (
    <div className="p-6 space-y-5 min-h-full">
      <div>
        <h1 className="text-xl font-bold text-[#e2e8f0]">Incidents</h1>
        <p className="text-xs text-[#64748b] mt-0.5">Correlated threat incidents</p>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <select value={statusFilter} onChange={e => { setStatusFilter(e.target.value); }}
          className="bg-[#0d1528] border border-[#1a2744] text-sm text-[#e2e8f0] rounded-lg px-3 py-2 outline-none focus:border-[#00d4ff]/40">
          <option value="">All Statuses</option>
          <option value="open">Open</option>
          <option value="in_progress">In Progress</option>
          <option value="resolved">Resolved</option>
        </select>
        <select value={severityFilter} onChange={e => { setSeverityFilter(e.target.value); }}
          className="bg-[#0d1528] border border-[#1a2744] text-sm text-[#e2e8f0] rounded-lg px-3 py-2 outline-none focus:border-[#00d4ff]/40">
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <input
          type="text" placeholder="Search by title..."
          value={search} onChange={e => setSearch(e.target.value)}
          className="flex-1 bg-[#0d1528] border border-[#1a2744] text-sm text-[#e2e8f0] rounded-lg px-3 py-2 outline-none focus:border-[#00d4ff]/40 placeholder-[#64748b]"
        />
      </div>

      {/* Cards grid */}
      <div className="grid grid-cols-2 gap-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
          : incidents.length === 0
          ? (
            <div className="col-span-2 flex flex-col items-center justify-center py-24 text-[#64748b]">
              <div className="text-5xl mb-3">🔴</div>
              <div className="text-sm">No incidents yet</div>
              <div className="text-xs mt-1">Incidents are created when multiple alerts correlate</div>
            </div>
          )
          : incidents.map(inc => (
            <IncidentCard key={inc.incident_id} inc={inc} onSelect={() => setSelected(inc)} />
          ))
        }
      </div>

      {/* Detail panel */}
      {selected && (
        <>
          <div className="fixed inset-0 bg-black/40 z-40" onClick={() => setSelected(null)} />
          <DetailPanel inc={selected} onClose={() => setSelected(null)} />
        </>
      )}
    </div>
  );
}
