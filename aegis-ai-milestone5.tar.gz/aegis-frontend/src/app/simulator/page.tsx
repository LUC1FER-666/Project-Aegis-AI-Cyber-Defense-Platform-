"use client";

import { useState } from "react";
import { analyzeEvent, type AnalyzeResponse } from "@/lib/api";
import JsonViewer from "@/components/JsonViewer";

interface HistoryEntry {
  id: string;
  template: string;
  event: Record<string, unknown>;
  result: AnalyzeResponse | null;
  ts: string;
  ok: boolean;
}

const TEMPLATES: Record<string, { label: string; icon: string; color: string; payload: Record<string, unknown> }> = {
  powershell: {
    label: "PowerShell Attack",
    icon: "⚡",
    color: "#ff4444",
    payload: {
      event_type: "process",
      category: "process",
      source_log_type: "windows_event",
      hostname: "WORKSTATION-01",
      asset_id: "asset-ws01",
      timestamp: new Date().toISOString(),
      process_name: "powershell.exe",
      command_line: "powershell.exe -EncodedCommand JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0AA==",
      parent_process: "cmd.exe",
      user: "jsmith",
      pid: 4821,
      severity: "high",
    },
  },
  bruteforce: {
    label: "Brute Force Auth",
    icon: "🔑",
    color: "#ff8800",
    payload: {
      event_type: "auth",
      category: "auth",
      source_log_type: "auth",
      hostname: "DC-01",
      asset_id: "asset-dc01",
      timestamp: new Date().toISOString(),
      username: "administrator",
      src_ip: "192.168.100.42",
      dest_ip: "10.0.0.1",
      auth_result: "failure",
      failure_count: 15,
      protocol: "SMB",
      severity: "high",
    },
  },
  dns: {
    label: "DNS Tunneling",
    icon: "🌐",
    color: "#f59e0b",
    payload: {
      event_type: "dns",
      category: "dns",
      source_log_type: "dns",
      hostname: "WORKSTATION-03",
      asset_id: "asset-ws03",
      timestamp: new Date().toISOString(),
      query: "aGVsbG8ud29ybGQ.exfil.attacker.com",
      query_type: "TXT",
      response_code: "NOERROR",
      src_ip: "10.0.0.55",
      bytes_out: 4096,
      severity: "medium",
    },
  },
  c2: {
    label: "C2 Connection",
    icon: "📡",
    color: "#ff4444",
    payload: {
      event_type: "network",
      category: "network",
      source_log_type: "netflow",
      hostname: "SERVER-02",
      asset_id: "asset-srv02",
      timestamp: new Date().toISOString(),
      src_ip: "10.0.0.21",
      dest_ip: "185.220.101.55",
      dest_port: 4444,
      protocol: "TCP",
      bytes_sent: 8192,
      bytes_received: 1024,
      connection_state: "established",
      severity: "critical",
    },
  },
  lateral: {
    label: "Lateral Movement",
    icon: "↔",
    color: "#ff8800",
    payload: {
      event_type: "network",
      category: "network",
      source_log_type: "windows_event",
      hostname: "WORKSTATION-01",
      asset_id: "asset-ws01",
      timestamp: new Date().toISOString(),
      event_id: 4624,
      logon_type: 3,
      src_ip: "10.0.0.42",
      dest_hostname: "SERVER-02",
      username: "jsmith",
      auth_package: "NTLM",
      severity: "high",
    },
  },
};

export default function SimulatorPage() {
  const [activeTemplate, setActiveTemplate] = useState("powershell");
  const [jsonText, setJsonText] = useState(JSON.stringify(TEMPLATES.powershell.payload, null, 2));
  const [submitting, setSubmitting] = useState(false);
  const [lastResult, setLastResult] = useState<AnalyzeResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const selectTemplate = (key: string) => {
    setActiveTemplate(key);
    setJsonText(JSON.stringify(TEMPLATES[key].payload, null, 2));
    setLastResult(null);
    setError(null);
  };

  const submit = async () => {
    setSubmitting(true);
    setError(null);
    setLastResult(null);

    let parsed: Record<string, unknown>;
    try {
      parsed = JSON.parse(jsonText);
    } catch {
      setError("Invalid JSON — fix the syntax and try again");
      setSubmitting(false);
      return;
    }

    const result = await analyzeEvent(parsed);
    setLastResult(result);

    const entry: HistoryEntry = {
      id: Date.now().toString(),
      template: TEMPLATES[activeTemplate]?.label ?? activeTemplate,
      event: parsed,
      result,
      ts: new Date().toLocaleTimeString(),
      ok: result !== null,
    };
    setHistory(prev => [entry, ...prev].slice(0, 10));
    setSubmitting(false);
  };

  const tpl = TEMPLATES[activeTemplate];

  return (
    <div className="p-6 space-y-5 min-h-full">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-[#e2e8f0]">Event Simulator</h1>
        <p className="text-xs text-[#64748b] mt-0.5">Submit synthetic telemetry to the detection engine and watch alerts fire in real time</p>
      </div>

      <div className="grid grid-cols-3 gap-5">
        {/* Left: templates + editor */}
        <div className="col-span-2 space-y-4">
          {/* Template buttons */}
          <div className="grid grid-cols-5 gap-2">
            {Object.entries(TEMPLATES).map(([key, t]) => (
              <button
                key={key}
                onClick={() => selectTemplate(key)}
                className={`flex flex-col items-center gap-1.5 px-3 py-3 rounded-xl border text-xs font-medium transition-all duration-150 ${
                  activeTemplate === key
                    ? "border-opacity-60 bg-opacity-10"
                    : "border-[#1a2744] bg-[#0d1528] text-[#64748b] hover:text-[#e2e8f0] hover:border-[#1a2744]/80"
                }`}
                style={activeTemplate === key ? {
                  borderColor: t.color,
                  background: `${t.color}15`,
                  color: t.color,
                } : {}}
              >
                <span className="text-xl">{t.icon}</span>
                <span className="text-center leading-tight">{t.label}</span>
              </button>
            ))}
          </div>

          {/* JSON Editor */}
          <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#1a2744]">
              <div className="flex items-center gap-2">
                <span className="text-sm" style={{ color: tpl?.color }}>{tpl?.icon}</span>
                <span className="text-xs text-[#e2e8f0] font-medium">{tpl?.label}</span>
                <span className="text-[10px] text-[#64748b]">— edit payload below</span>
              </div>
              <button
                onClick={() => setJsonText(JSON.stringify(TEMPLATES[activeTemplate].payload, null, 2))}
                className="text-[10px] text-[#64748b] hover:text-[#00d4ff] transition-colors"
              >
                Reset
              </button>
            </div>
            <textarea
              value={jsonText}
              onChange={e => setJsonText(e.target.value)}
              className="w-full bg-[#060d1f] text-[#e2e8f0] font-mono text-xs p-4 outline-none resize-none leading-relaxed"
              rows={18}
              spellCheck={false}
            />
          </div>

          {/* Error */}
          {error && (
            <div className="bg-[#ff4444]/10 border border-[#ff4444]/30 rounded-lg px-4 py-3 text-sm text-[#ff4444]">
              {error}
            </div>
          )}

          {/* Submit */}
          <button
            onClick={submit}
            disabled={submitting}
            className="w-full py-3 rounded-xl font-semibold text-sm transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: submitting ? "#00d4ff22" : "linear-gradient(135deg, #00d4ff22, #00d4ff44)",
              color: "#00d4ff",
              border: "1px solid #00d4ff44",
              boxShadow: submitting ? "none" : "0 0 20px #00d4ff11",
            }}
          >
            {submitting ? "▶ Analyzing..." : "▶ Submit to Detection Engine"}
          </button>

          {/* Result */}
          {lastResult !== null && (
            <div className="bg-[#0d1528] border border-[#00ff88]/20 rounded-xl overflow-hidden">
              <div className="px-4 py-2.5 border-b border-[#1a2744] flex items-center gap-2">
                <span className="text-[#00ff88] text-sm">✓</span>
                <span className="text-xs text-[#00ff88] font-medium">Detection Engine Response</span>
              </div>
              <div className="p-4 space-y-3">
                {/* Quick stats */}
                <div className="grid grid-cols-3 gap-2">
                  {[
                    ["Alerts Created", Array.isArray(lastResult.alerts) ? lastResult.alerts.length : (lastResult.alerts ? 1 : 0), "#ff4444"],
                    ["Rule Matches", Array.isArray(lastResult.rule_matches) ? lastResult.rule_matches.length : 0, "#ff8800"],
                    ["LLM Validated", lastResult.llm_validated ? "Yes" : "No", "#00d4ff"],
                  ].map(([k, v, c]) => (
                    <div key={String(k)} className="bg-[#060d1f] rounded-lg p-3 border border-[#1a2744] text-center">
                      <div className="text-lg font-bold" style={{ color: String(c) }}>{String(v)}</div>
                      <div className="text-[10px] text-[#64748b] mt-0.5">{String(k)}</div>
                    </div>
                  ))}
                </div>
                <JsonViewer data={lastResult} maxHeight="250px" />
              </div>
            </div>
          )}

          {lastResult === null && !submitting && history.length > 0 && (
            <div className="bg-[#ff4444]/10 border border-[#ff4444]/30 rounded-xl p-4 text-sm text-[#ff4444]">
              ⚠ Detection engine not reachable — start it with <code className="font-mono text-xs bg-[#1a2744] px-1 rounded">uvicorn app.main:app --port 8004</code>
            </div>
          )}
        </div>

        {/* Right: history */}
        <div className="space-y-3">
          <h3 className="text-xs text-[#64748b] uppercase tracking-widest">Submission History</h3>
          {history.length === 0 ? (
            <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl p-6 text-center text-[#64748b] text-xs">
              No events submitted yet
            </div>
          ) : (
            <div className="space-y-2">
              {history.map(h => (
                <div key={h.id} className={`bg-[#0d1528] border rounded-xl p-4 space-y-2 ${h.ok ? "border-[#1a2744]" : "border-[#ff4444]/20"}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-[#e2e8f0]">{h.template}</span>
                    <span className="text-[10px] text-[#64748b]">{h.ts}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs ${h.ok ? "text-[#00ff88]" : "text-[#ff4444]"}`}>
                      {h.ok ? "✓ Received" : "✗ Failed"}
                    </span>
                    {h.result && Array.isArray(h.result.alerts) && (
                      <span className="text-[10px] text-[#64748b]">{h.result.alerts.length} alert(s)</span>
                    )}
                  </div>
                  {h.result && (
                    <div className="max-h-24 overflow-hidden rounded text-[10px] font-mono bg-[#060d1f] p-2 border border-[#1a2744] text-[#64748b] overflow-y-auto">
                      {JSON.stringify(h.result, null, 1).slice(0, 300)}...
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
