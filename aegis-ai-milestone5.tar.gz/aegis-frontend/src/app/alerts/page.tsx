"use client";

import { useEffect, useState, useCallback } from "react";
import { fetchAlerts, type Alert, timeAgo } from "@/lib/api";
import SeverityBadge from "@/components/SeverityBadge";
import StatusBadge from "@/components/StatusBadge";
import JsonViewer from "@/components/JsonViewer";
import { SkeletonRow } from "@/components/LoadingSkeleton";

const PAGE_SIZE = 50;

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [severity, setSeverity] = useState("");
  const [status, setStatus] = useState("");
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true);
    const data = await fetchAlerts({
      limit: PAGE_SIZE,
      offset: page * PAGE_SIZE,
      severity: severity || undefined,
      status: status || undefined,
      search: search || undefined,
    });
    setAlerts(data);
    setLoading(false);
  }, [page, severity, status, search]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    const t = setInterval(refresh, 10_000);
    return () => clearInterval(t);
  }, [refresh]);

  const applySearch = () => { setSearch(searchInput); setPage(0); };

  return (
    <div className="p-6 space-y-5 min-h-full">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-[#e2e8f0]">Alerts</h1>
        <p className="text-xs text-[#64748b] mt-0.5">All detection engine alerts · live feed</p>
      </div>

      {/* Filter bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <select
          value={severity}
          onChange={e => { setSeverity(e.target.value); setPage(0); }}
          className="bg-[#0d1528] border border-[#1a2744] text-sm text-[#e2e8f0] rounded-lg px-3 py-2 outline-none focus:border-[#00d4ff]/40"
        >
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>

        <select
          value={status}
          onChange={e => { setStatus(e.target.value); setPage(0); }}
          className="bg-[#0d1528] border border-[#1a2744] text-sm text-[#e2e8f0] rounded-lg px-3 py-2 outline-none focus:border-[#00d4ff]/40"
        >
          <option value="">All Statuses</option>
          <option value="open">Open</option>
          <option value="in_progress">In Progress</option>
          <option value="resolved">Resolved</option>
          <option value="suppressed">Suppressed</option>
        </select>

        <div className="flex flex-1 gap-2">
          <input
            type="text"
            placeholder="Search rule ID or asset ID..."
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && applySearch()}
            className="flex-1 bg-[#0d1528] border border-[#1a2744] text-sm text-[#e2e8f0] rounded-lg px-3 py-2 outline-none focus:border-[#00d4ff]/40 placeholder-[#64748b]"
          />
          <button
            onClick={applySearch}
            className="px-4 py-2 bg-[#00d4ff]/10 text-[#00d4ff] border border-[#00d4ff]/30 rounded-lg text-sm hover:bg-[#00d4ff]/20 transition-colors"
          >
            Search
          </button>
        </div>

        <button onClick={() => { setSeverity(""); setStatus(""); setSearch(""); setSearchInput(""); setPage(0); }}
          className="text-xs text-[#64748b] hover:text-[#e2e8f0] transition-colors px-2">
          Clear
        </button>
      </div>

      {/* Table */}
      <div className="bg-[#0d1528] border border-[#1a2744] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1a2744]">
                {["Severity", "Rule ID", "Asset", "MITRE", "Confidence", "Log Type", "LLM", "Status", "Time"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-[10px] text-[#64748b] uppercase tracking-widest font-medium whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading
                ? Array.from({ length: 8 }).map((_, i) => <SkeletonRow key={i} cols={9} />)
                : alerts.length === 0
                ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-16 text-center">
                      <div className="text-[#64748b] space-y-2">
                        <div className="text-3xl">⚡</div>
                        <div className="text-sm">No alerts match your filters</div>
                        <div className="text-xs">Try the Event Simulator to generate alerts</div>
                      </div>
                    </td>
                  </tr>
                )
                : alerts.map(a => (
                  <>
                    <tr
                      key={a.alert_id}
                      onClick={() => setExpanded(expanded === a.alert_id ? null : a.alert_id)}
                      className="border-b border-[#1a2744]/50 hover:bg-[#1a2744]/20 transition-colors cursor-pointer"
                    >
                      <td className="px-4 py-3"><SeverityBadge severity={a.severity} /></td>
                      <td className="px-4 py-3 font-mono text-xs text-[#00d4ff] whitespace-nowrap">{a.rule_id}</td>
                      <td className="px-4 py-3 text-xs text-[#e2e8f0] max-w-[120px] truncate">{a.asset_id || "—"}</td>
                      <td className="px-4 py-3 text-xs font-mono text-[#64748b] whitespace-nowrap">{a.mitre_technique}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-14 h-1.5 bg-[#1a2744] rounded-full overflow-hidden">
                            <div className="h-full bg-[#00d4ff] rounded-full" style={{ width: `${(a.confidence_score ?? 0) * 100}%` }} />
                          </div>
                          <span className="text-xs text-[#64748b]">{Math.round((a.confidence_score ?? 0) * 100)}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-[#64748b]">{a.source_log_type}</td>
                      <td className="px-4 py-3">
                        {a.llm_validated
                          ? <span title="LLM validated" className="text-[#00ff88] text-base">✓</span>
                          : <span title="Not LLM validated" className="text-[#64748b] text-base">—</span>}
                      </td>
                      <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#64748b] whitespace-nowrap">{timeAgo(a.created_at)}</td>
                    </tr>
                    {expanded === a.alert_id && (
                      <tr key={`${a.alert_id}-exp`} className="bg-[#060d1f]">
                        <td colSpan={9} className="px-6 py-4">
                          <div className="space-y-2">
                            <p className="text-xs text-[#64748b] uppercase tracking-widest">Evidence</p>
                            <JsonViewer data={a.evidence} maxHeight="200px" />
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                ))
              }
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-4 py-3 border-t border-[#1a2744] flex items-center justify-between">
          <span className="text-xs text-[#64748b]">
            Showing {page * PAGE_SIZE + 1}–{page * PAGE_SIZE + alerts.length}
          </span>
          <div className="flex gap-2">
            <button
              disabled={page === 0}
              onClick={() => setPage(p => p - 1)}
              className="px-3 py-1.5 text-xs bg-[#1a2744] text-[#e2e8f0] rounded disabled:opacity-40 hover:bg-[#1a2744]/80 transition-colors"
            >
              ← Prev
            </button>
            <button
              disabled={alerts.length < PAGE_SIZE}
              onClick={() => setPage(p => p + 1)}
              className="px-3 py-1.5 text-xs bg-[#1a2744] text-[#e2e8f0] rounded disabled:opacity-40 hover:bg-[#1a2744]/80 transition-colors"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
